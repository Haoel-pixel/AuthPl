0.24.0 - 1.21.1 - 1.21.4 Support

- Add support for 1.21.4
- Add support for Java 23
- Fix "logged in from another location" issue on Paper (see GH #296)